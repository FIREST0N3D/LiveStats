# LiveStats language pack

Oxide folders: `oxide/lang/<code>/<Plugin>.json`

## Complete or near-complete

| Folder | Language | Notes |
|---|---|---|
| en | English | source |
| nl | Dutch | full |
| de | German | full |
| ru | Russian | full |
| zh-CN | Simplified Chinese | full |
| en-PT | Pirate English | full player-facing |
| pirate | Pirate alias | same as en-PT |

## All other official Rust languages — packs generated

Every folder below has all 6 plugin files and is safe to install.
Core stats, death causes, animal/NPC names, kill-feed templates, and common event names/spawns are translated.
Some system/help lines still fall back to English and can be finished next.

`fr` `it` `es` `es-ES` `es-419` `ja` `ko` `uk` `pl` `pt` `pt-PT` `pt-BR` `tr` `ar` `cs` `da` `fi` `el` `no` `sv` `zh-TW` `vi`

Aliases: `es-ES` = Spain Spanish, `pt-PT` = Portugal Portuguese.

Pirate is an in-game flag. Use `en-PT` (or `/lang pirate`).

## Install

Copy `lang/*` into `oxide/lang/` (Carbon: `carbon/lang/`), then reload the six plugins.
